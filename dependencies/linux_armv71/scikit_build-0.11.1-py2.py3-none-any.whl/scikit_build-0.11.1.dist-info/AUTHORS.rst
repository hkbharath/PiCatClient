=======
Credits
=======

Please see the GitHub project page at https://github.com/scikit-build/scikit-build/graphs/contributors

